#include "Network_Layer.h"

Define_Module(Network_Layer);

void Network_Layer::initialize()
{
    address=par("id");
    counter=0;
    id=-1;
    in=gate("fromDLL");
    out=gate("toDLL");
    if(address==1)
    {
        cMessage *sfmsg=new cMessage();
        scheduleAt(0, sfmsg);
    }
}

void Network_Layer::handleMessage(cMessage *msg)
{
    if(msg -> isSelfMessage())
    {
        N_PDU *pkt=new N_PDU();
        pkt -> setType("Data");
        send(pkt, out);
        counter++;
        delete(msg);
        par("remaining_packets")=(int)par("remaining_packets")-1;
        if(!(int)par("remaining_packets"))
            return;
        cMessage *sfmsg=new cMessage();
        scheduleAt(simTime()+200, sfmsg);
    }
    else
    {
        delete(msg);
    }
}
