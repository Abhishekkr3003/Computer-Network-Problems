#include "Data_Link_Layer.h"

Define_Module(Data_Link_Layer);

void Data_Link_Layer::initialize()
{
    fromNL=gate("fromNL");
    toNL=gate("toNL");
    fromNode=gate("fromNode");
    toNode=gate("toNode");
    id=-1;
}

void Data_Link_Layer::handleMessage(cMessage *msg)
{
    if(msg -> getArrivalGate() == fromNL)
    {
        N_PDU *pkt=check_and_cast<N_PDU*>(msg);
        DL_PDU *frm=new DL_PDU();
        id++;
        id=id%2;
        frm->encapsulate(pkt);
        frm->setType("Data");
        frm->setPID(id);
        frm->setSrc(1);
        frm->setDest(2);
        send(frm, toNode);
    }
    else
    {
        DL_PDU *frm=check_and_cast<DL_PDU*>(msg);
        if(strcmp(frm->getType(), "Data")==0)
        {
            DL_PDU *p=new DL_PDU();
            p->setPID(frm->getPID());
            p->setType("Ack");
            p->setSrc(2);
            p->setDest(1);
            send(p, toNode);
            send(frm->decapsulate(), toNL);
            delete(frm);

        }
        else
        {
            delete(msg);
        }
    }
}
