#ifndef __LAB2_NETWORK_LAYER_H_
#define __LAB2_NETWORK_LAYER_H_

#include <omnetpp.h>
#include <N_PDU_m.h>

using namespace omnetpp;

class Network_Layer : public cSimpleModule
{
  protected:
    int address;
    int counter;
    int id;
    cGate *in;
    cGate *out;
    virtual void initialize();
    virtual void handleMessage(cMessage *msg);
};

#endif
