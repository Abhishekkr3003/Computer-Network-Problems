#ifndef __LAB1_NODE_H_
#define __LAB1_NODE_H_

#include <omnetpp.h>
#include <N_PDU_m.h>

using namespace omnetpp;

class Node : public cSimpleModule
{
    int address;
    cGate *in;
    cGate *out;
    int counter;
    int id_num;

  protected:
    virtual void initialize();
    virtual void handleMessage(cMessage *msg);
};

#endif
