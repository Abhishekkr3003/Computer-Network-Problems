#include "node.h"

Define_Module(Node);

void Node::initialize()
{
    address=par("id");
    in=gate("Gate_Input");
    out=gate("Gate_Output");
    counter=0;
    id_num=0;

    if(address==0)
    {
        cMessage *msg=new cMessage();
        scheduleAt(0, msg);

    }
}

void Node::handleMessage(cMessage *msg)
{
    if(msg -> isSelfMessage())
    {
        N_PDU *pkt=new N_PDU();
        pkt -> setId(++id_num);
        pkt -> setType("Data");
        pkt -> setSource(1);
        pkt -> setDestination(2);
        send(pkt, out);
    }
    else
    {
        N_PDU *in_msg=check_and_cast<N_PDU*>(msg);
        if(strcmp(in_msg -> getType(),"Data")==0)
        {
            N_PDU *pkt1=new N_PDU();
            pkt1 -> setId(in_msg->getId());
            pkt1 -> setType("Ack");
            pkt1 -> setSource(2);
            pkt1 -> setDestination(1);
            send(pkt1, out);
        }
        else
        {
            counter++;
            if(counter==10)
                return;
            N_PDU *pkt2=new N_PDU();
            pkt2 -> setId(++id_num);
            pkt2 -> setType("Data");
            pkt2 -> setSource(1);
            pkt2 -> setDestination(2);
            send(pkt2, out);
        }
    }
}
