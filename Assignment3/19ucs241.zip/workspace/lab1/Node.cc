#include "Node.h"

Define_Module(Node);

void Node::initialize()
{
    id=1;
    strcpy(type,"Data");
    source=getIndex();
    destination=par("destination");
    if(strcmp("Node1", getName())==0)
    {
        N_PDU=new Packet();
        N_PDU->setSource(source);
        N_PDU->setDestination(destination);
        N_PDU->setId(id);
        N_PDU->setType(type);
        send(N_PDU, "Gate_Output");
    }
}

void Node::handleMessage(cMessage *msg)
{
    if(strcmp("Node1", getName())==0)
    {
        Packet *in_msg=check_and_cast<Packet*>(msg);
        if(in_msg->getId()==10)
            endSimulation();
        id++;
        strcpy(type,"Data");
        source=getIndex();
        destination=par("destination");
        N_PDU=new Packet();
        N_PDU->setSource(in_msg->getDestination());
        N_PDU->setDestination(in_msg->getSource());
        N_PDU->setId(id);
        N_PDU->setType(type);
        send(N_PDU, "Gate_Output");
    }
    if(strcmp("Node2", getName())==0)
    {
        Packet *in_msg=check_and_cast<Packet*>(msg);
        strcpy(type,"Ack");
        source=getIndex();
        destination=par("destination");
        N_PDU=new Packet();
        N_PDU->setSource(in_msg->getDestination());
        N_PDU->setDestination(in_msg->getSource());
        N_PDU->setId(in_msg->getId());
        N_PDU->setType(type);
        send(N_PDU, "Gate_Output");
    }
}
