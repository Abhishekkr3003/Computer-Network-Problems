#ifndef __LAB1_NODE_H_
#define __LAB1_NODE_H_

#include <omnetpp.h>
#include <Packet_m.h>

using namespace omnetpp;

class Node : public cSimpleModule
{
    int id;
    char type[5];
    int source;
    int destination;
    Packet *N_PDU;

  protected:
    virtual void initialize();
    virtual void handleMessage(cMessage *msg);
};

#endif
